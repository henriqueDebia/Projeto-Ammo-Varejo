'use strict';
const {
  Model
} = require('sequelize');
module.exports = (sequelize, DataTypes) => {
  class Produtos extends Model {
 
    static associate(models) {
    
    }
  }
  Produtos.init({
    nome: DataTypes.STRING,
    descrição: DataTypes.STRING,
    categoria: DataTypes.STRING,
    preço: DataTypes.NUMBER
  }, {
    sequelize,
    modelName: 'Produtos',
  });
  return Produtos;
};