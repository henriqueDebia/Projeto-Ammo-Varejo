window.onload = () => {
    
    const cadastrar = document.getElementById('cadastrar')
    
    console.log('iniciado')
    cadastrar.onclick = novoProduto;
}

form.addEventListener('submit', (e) => {
    e.preventDefault()
})

const novoProduto = async () => {
    
    
    const produtoNomeElement = document.getElementById('nome');
    const produtoDescricaoElement = document.getElementById('descricao');
    const produtoPrecoElement = document.getElementById('preco');
    const produtoCategoriaElement = document.getElementById('categoria');
    
    const produto = {
        nome: produtoNomeElement.value,
        descrição: produtoDescricaoElement.value,
        preço: Number(produtoPrecoElement.value),
        categoria: produtoCategoriaElement.value,
    }
    
    const init = {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(produto)
    }
    
    if(produtoNomeElement.value.length > 1 && produtoDescricaoElement.value.length > 9 && produtoPrecoElement.value > 0 && produtoCategoriaElement.value.length > 3) {    
        
        const response = await fetch('http://localhost:3000/produtos', init)
        const dados = await response.json()
        alert('Produto Cadastrado')
    }
}

