
const express = require('express')
const routes = require('../api/routes')
const cors = require('cors');

const app = express()
const port = 3000

app.use(cors())
app.use(express.json());
app.use((req, res, next) => {
    res.header("Access-Control-Allow-Origin", "*")
    res.header("Access-Control-Allow-Methods", "GET,PUT,POST,DELETE")
    app.use(cors());
    next();
})

routes(app)

app.listen(port, () => console.log(`servidor está rodando na porta ${port}`))

module.exports = app