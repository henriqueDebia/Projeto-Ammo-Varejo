window.onload = () => {
    CarregarProdutos();
    semProdutos()
}

const listaDeProdutos = document.getElementById('listaDeProdutos');
const searchBar = document.getElementById('searchBar');
let todosProdutos = [];

searchBar.addEventListener('keyup', (e) => {
    const searchString = e.target.value.toLowerCase();
    
    const produtosFiltrados = todosProdutos.filter((produtos) => {
        return (
            produtos.nome.toLowerCase().includes(searchString) ||
            produtos.descrição.toLowerCase().includes(searchString) ||
            produtos.categoria.toLowerCase().includes(searchString)
            );
        });
        displayProdutos(produtosFiltrados);
});

const CarregarProdutos = async () => {
    try {
        const response = await fetch('http://localhost:3000/produtos/');
        todosProdutos = await response.json();
        displayProdutos(todosProdutos);
    } catch (err) {
        console.error(err);
    }
};

const displayProdutos = (produtos) => {
    const htmlString = produtos
        .map((produtos) => {
            return `
            <li class="produtos">
                <h2 class="produtos-nome">${produtos.nome}</h2>
                <p class="produtos-descricao">Descrição: ${produtos.descrição}</p>
                <p class="produtos-preco">Preço: R$ ${produtos.preço},00</p>
                <p class="produtos-categoria">Categoria: ${produtos.categoria}</p>
            </li>
        `;
        })
        .join('');
    listaDeProdutos.innerHTML = htmlString;
};

async function semProdutos() {

    const response = await fetch('http://localhost:3000/produtos/')
    const dados = await response.json();
    console.log(dados)

    if(dados.length == 0) {

        const containerProdutos = document.getElementById('container-sproduto');
        const template = document.getElementById('template-sproduto');
        const semProdutos = document.importNode(template.content, true);
        const itens_semProdutos = semProdutos.querySelectorAll('span')
        
        itens_semProdutos[0].innerText = 'Nenhum produto cadastrado!'
        
        containerProdutos.append(semProdutos)
    }
    
}

